Copy jni and build.sh to curl folder.
run build.sh
copy culr_folder/obj/local/armeabi-v7a/libcurl_android.a to lib folder