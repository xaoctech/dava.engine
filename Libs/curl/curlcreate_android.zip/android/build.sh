#!/bin/sh

ndk_root=$ANDROID_NDK_ROOT
ndk_platform="android-5"
toolchain="arm-linux-androideabi-4.6/prebuilt/darwin-x86"
if [ $1 ]
then
	ndk_root=$1
fi

if [ ! -d "${ndk_root}" ]
then
    echo " "
    echo "Oopsie. Please specify the path to the Android Ndk. (./build.sh /path/to/ndk)"
    exit 1
fi

CPPFLAGS="-I $ndk_root/platforms/$ndk_platform/arch-arm/usr/include \
-L $ndk_root/platforms/$ndk_platform/arch-arm/usr/lib" \
CFLAGS="-fno-exceptions -Wno-multichar -mthumb -mthumb-interwork -nostdlib -lc -ldl -lm " \
./configure --host=arm-linux CC=$ndk_root/toolchains/$toolchain/bin/arm-linux-androideabi-gcc

$ndk_root/ndk-build